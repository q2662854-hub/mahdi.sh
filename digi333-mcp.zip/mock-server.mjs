/**
 * Tiny local HTTP server that replays captured WooCommerce Store API responses.
 * Use it to test digi333-mcp without network access:
 *   DIGI333_BASE_URL=http://127.0.0.1:8911 node src/index.js
 * Routes:
 *   GET /wp-json/wc/store/v1/products
 *   GET /wp-json/wc/store/v1/products/{id}
 *   GET /wp-json/wc/store/v1/products/categories
 */
import { createServer } from "node:http";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const HERE = dirname(fileURLToPath(import.meta.url));
const read = (f) => JSON.parse(readFileSync(join(HERE, "testdata", f), "utf8"));

const products = read("products.json");
const single = read("product-2404.json");
const categories = read("categories.json");

const PORT = Number(process.env.MOCK_PORT || 8911);

createServer((req, res) => {
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  const url = new URL(req.url, "http://localhost");

  if (url.pathname === "/wp-json/wc/store/v1/products") {
    // Honor ?category= filtering so category-based searches work too.
    const cat = url.searchParams.get("category");
    const body = cat ? products.filter((p) => (p.categories || []).some((c) => String(c.id) === String(cat))) : products;
    res.end(JSON.stringify(body));
    return;
  }
  if (url.pathname === "/wp-json/wc/store/v1/products/categories") {
    res.end(JSON.stringify(categories));
    return;
  }
  const m = url.pathname.match(/^\/wp-json\/wc\/store\/v1\/products\/(\d+)$/);
  if (m) {
    res.end(JSON.stringify(single));
    return;
  }
  res.statusCode = 404;
  res.end(JSON.stringify({ code: "rest_no_route", message: "No route was found matching the URL and request method." }));
}).listen(PORT, "127.0.0.1", () => {
  console.log(`mock store api on http://127.0.0.1:${PORT}`);
});
