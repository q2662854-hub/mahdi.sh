# digi333-mcp

MCP (Model Context Protocol) server that exposes **digi333.ir** (دیجی ۳۳۳, a WooCommerce store) as tools for AI assistants.

The server talks to the store's **public WooCommerce Store API** (`/wp-json/wc/store/v1/...`) — no credentials, no scraping of HTML. Prices come back in **Iranian Toman (IRT)**.

## Tools

| Tool | Description |
| --- | --- |
| `search_products` | Search/filter products: keyword, category, price range, on-sale, sorting, pagination. Returns a compact list (id, name, price, rating, stock, category, image). |
| `get_product_details` | Full detail for one product by id: description, attributes, gallery, stock, pricing, add-to-cart URL. |
| `list_categories` | Category tree (top-level or children of a given `parent_id`), with product counts. |

All tools return JSON as `text` content blocks.

## Requirements

- **Node.js ≥ 18.17** (global `fetch` required). A portable copy is already bundled next to this project at `../.tools/node-v20.20.2-win-x64/` — use it if Node is not installed on the machine.

## Install & run

```bash
cd digi333-mcp
npm install
npm start          # = node src/index.js  (stdio transport)
```

The server speaks the MCP protocol over **stdio**, so any MCP client can spawn it:

```json
{
  "mcpServers": {
    "digi333": {
      "command": "node",
      "args": ["C:/path/to/digi333-mcp/src/index.js"],
      "env": {}
    }
  }
}
```

## Environment variables

| Variable | Default | Purpose |
| --- | --- | --- |
| `DIGI333_BASE_URL` | `https://digi333.ir` | Base URL of the store (handy for proxies/mirrors). |
| `DIGI333_TIMEOUT_MS` | `20000` | Request timeout in milliseconds. |
| `DIGI333_USER_AGENT` | `digi333-mcp/1.0` | User-Agent header. |

## Testing

The store API is verified against **captured real responses** in `testdata/` (products, a full product, categories). To run the full MCP conversation offline:

```bash
# terminal 1 — replay the captured API locally
node mock-server.mjs            # listens on 127.0.0.1:8911

# terminal 2 — smoke-test the server (lists tools, calls each tool)
set DIGI333_BASE_URL=http://127.0.0.1:8911
node test-client.mjs node src/index.js
```

## Notes & troubleshooting

- **Site availability:** during development, digi333.ir was periodically unreachable (TLS handshakes reset, HTTP 522 via third-party proxies) even though it worked at other moments. The client retries transient failures (429/5xx and network resets) with backoff, but if the site is mid-outage the tools will error with the underlying cause.
- **Network/DNS:** this store resolves to `198.18.x.x` (benchmark range) on some networks — a sign of DNS-level interception/DPI. If `fetch` fails with `ECONNRESET` while `curl` works, the path between you and the site is filtering/altering TLS; run the server on a network without such interference, or point `DIGI333_BASE_URL` at a working mirror.
- **Read-only:** the server performs only `GET` requests and never modifies the store.
