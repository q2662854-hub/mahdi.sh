/**
 * Minimal stdio MCP client for smoke-testing digi333-mcp.
 * Spawns the server, lists tools, and calls each tool once.
 */
import { spawn } from "node:child_process";

const SERVER_CMD = process.argv[2] || "node";
const SERVER_ARGS = process.argv[3] ? [process.argv[3]] : ["src/index.js"];

const child = spawn(SERVER_CMD, SERVER_ARGS, {
  cwd: process.cwd(),
  stdio: ["pipe", "pipe", "pipe"],
});

let nextId = 1;
const pending = new Map();
let buffer = "";

child.stdout.setEncoding("utf8");
child.stdout.on("data", (chunk) => {
  buffer += chunk;
  let idx;
  while ((idx = buffer.indexOf("\n")) !== -1) {
    const line = buffer.slice(0, idx).trim();
    buffer = buffer.slice(idx + 1);
    if (!line) continue;
    try {
      const msg = JSON.parse(line);
      const resolve = pending.get(msg.id);
      if (resolve) {
        pending.delete(msg.id);
        resolve(msg);
      }
    } catch {
      // ignore non-JSON noise
    }
  }
});

child.stderr.setEncoding("utf8");
child.stderr.on("data", (d) => process.stderr.write("[server-stderr] " + d));

function request(method, params = {}) {
  const id = nextId++;
  return new Promise((resolve, reject) => {
    pending.set(id, resolve);
    child.stdin.write(JSON.stringify({ jsonrpc: "2.0", id, method, params }) + "\n");
    setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id);
        reject(new Error(`timeout waiting for response to ${method}`));
      }
    }, 60000);
  });
}

async function main() {
  const tools = await request("tools/list");
  console.log("TOOLS:", JSON.stringify(tools.result?.tools?.map((t) => t.name) ?? tools, null, 2));

  const search = await request("tools/call", { name: "search_products", arguments: { query: "سامسونگ", max_results: 3 } });
  const sr = search.result?.content?.[0]?.text;
  console.log("\nSEARCH:", sr ? sr.slice(0, 700) : JSON.stringify(search, null, 2));

  // First product id from search (fallback: 2404)
  let pid = 2404;
  try {
    const parsed = JSON.parse(sr);
    if (parsed.products?.length) pid = parsed.products[0].id;
  } catch { /* keep default */ }
  const detail = await request("tools/call", { name: "get_product_details", arguments: { product_id: pid } });
  const dr = detail.result?.content?.[0]?.text;
  console.log("\nDETAIL (id " + pid + "):", dr ? dr.slice(0, 900) : JSON.stringify(detail, null, 2));

  const cats = await request("tools/call", { name: "list_categories", arguments: {} });
  const cr = cats.result?.content?.[0]?.text;
  console.log("\nCATEGORIES:", cr ? cr.slice(0, 600) : JSON.stringify(cats, null, 2));

  child.kill();
  process.exit(0);
}

main().catch((e) => {
  console.error("TEST FAILED:", e);
  child.kill();
  process.exit(1);
});
