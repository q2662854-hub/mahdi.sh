/**
 * Minimal HTTP client for the public WooCommerce Store API of digi333.ir.
 * Docs: https://woocommerce.com/document/woocommerce-rest-api/#store-api
 */

const DEFAULT_BASE_URL = "https://digi333.ir";
const DEFAULT_TIMEOUT_MS = 20000;
const DEFAULT_USER_AGENT = "digi333-mcp/1.0 (+MCP server)";

export class Digi333Client {
  constructor({
    baseUrl = process.env.DIGI333_BASE_URL || DEFAULT_BASE_URL,
    timeoutMs = Number(process.env.DIGI333_TIMEOUT_MS) || DEFAULT_TIMEOUT_MS,
    userAgent = process.env.DIGI333_USER_AGENT || DEFAULT_USER_AGENT,
  } = {}) {
    this.baseUrl = baseUrl.replace(/\/+$/, "");
    this.timeoutMs = timeoutMs;
    this.userAgent = userAgent;
  }

  async request(path, params = {}, { maxRetries = 3 } = {}) {
    const url = new URL(`${this.baseUrl}/wp-json/wc/store/v1/${path}`);
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== null && value !== "") {
        url.searchParams.set(key, String(value));
      }
    }

    let lastError;
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), this.timeoutMs);
      try {
        const response = await fetch(url.toString(), {
          signal: controller.signal,
          headers: {
            Accept: "application/json",
            "User-Agent": this.userAgent,
          },
        });
        if (response.status === 429 || response.status >= 500) {
          // Polite backoff, then retry.
          await new Promise((resolve) => setTimeout(resolve, 500 * 2 ** attempt));
          lastError = new Error(`Store API responded ${response.status} for ${path}`);
          continue;
        }
        const body = await response.json().catch(() => null);
        if (!response.ok) {
          const detail = body?.message || body?.code || response.statusText;
          throw new Error(`Store API error ${response.status}: ${detail}`);
        }
        return { status: response.status, body };
      } catch (error) {
        if (error.name === "AbortError") {
          throw new Error(`Store API request timed out after ${this.timeoutMs}ms (${path})`);
        }
        lastError = error;
        if (attempt === maxRetries - 1) break;
      } finally {
        clearTimeout(timer);
      }
    }
    throw lastError;
  }

  /** Search/list products. Mirrors WooCommerce Store API product params. */
  async searchProducts({
    query,
    categoryId,
    minPrice,
    maxPrice,
    onSale,
    sortBy = "date",
    order = "desc",
    page = 1,
    perPage = 20,
  } = {}) {
    const params = {
      search: query,
      category: categoryId,
      min_price: minPrice,
      max_price: maxPrice,
      on_sale: onSale === undefined ? undefined : onSale ? "true" : "false",
      orderby: sortBy,
      order,
      page,
      per_page: Math.min(Math.max(perPage, 1), 100),
    };
    const { body } = await this.request("products", params);
    return body;
  }

  /** Full details for one product. */
  async getProduct(productId) {
    const { body } = await this.request(`products/${encodeURIComponent(productId)}`);
    return body;
  }

  /** Category tree. Pass parentId for children of a specific category. */
  async listCategories({ parentId, perPage = 100 } = {}) {
    const params = { per_page: perPage };
    if (parentId !== undefined) params.parent = parentId;
    const { body } = await this.request("products/categories", params);
    return body;
  }
}

/**
 * Shape a raw Store API product into a compact, readonly summary.
 */
export function summarizeProduct(product) {
  const prices = product.prices || {};
  return {
    id: product.id,
    name: product.name,
    slug: product.slug,
    link: product.permalink,
    sku: product.sku || null,
    price: {
      amount: prices.price,
      regular: prices.regular_price,
      sale: prices.sale_price,
      currency: prices.currency_code || "IRT",
    },
    on_sale: Boolean(product.on_sale),
    stock_status: product.stock_status || null,
    in_stock: Boolean(product.is_in_stock),
    rating: {
      average: product.average_rating,
      count: product.review_count,
    },
    categories: (product.categories || []).map((c) => ({ id: c.id, name: c.name })),
    has_options: Boolean(product.has_options),
    image: product.images?.[0]?.src || null,
    short_description: stripHtml(product.short_description || ""),
  };
}

/**
 * Shape the full product document (description, attributes, variations, gallery).
 */
export function expandProduct(product) {
  return {
    ...summarizeProduct(product),
    type: product.type,
    description: stripHtml(product.description || ""),
    attributes: (product.attributes || []).map((a) => ({
      name: a.name,
      values: (a.terms || []).map((t) => t.name),
    })),
    variations: (product.variations || []).map((v) => v.name),
    gallery: (product.images || []).map((i) => i.src),
    add_to_cart_url: product.add_to_cart?.url || null,
    sold_individually: Boolean(product.sold_individually),
  };
}

function stripHtml(html) {
  return String(html)
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
