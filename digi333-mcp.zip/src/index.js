/**
 * digi333-mcp — MCP server for digi333.ir (DiGi 333, a WooCommerce store).
 *
 * Talks to the public WooCommerce Store API:
 *   GET /wp-json/wc/store/v1/products
 *   GET /wp-json/wc/store/v1/products/{id}
 *   GET /wp-json/wc/store/v1/products/categories
 *
 * Run: node src/index.js   (stdio transport)
 */

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { Digi333Client, expandProduct, summarizeProduct } from "./digi333Client.js";

const server = new McpServer({
  name: "digi333-mcp",
  version: "1.0.0",
});

const client = new Digi333Client();

/** Standard text-only tool result. */
const textResult = (data) => ({
  content: [{ type: "text", text: JSON.stringify(data, null, 2) }],
});

server.tool(
  "search_products",
  "Search products on digi333.ir. Prices are in Iranian Toman (IRT). Returns a compact list; use get_product_details for the full image.",
  {
    query: z.string().optional().describe("Free-text keyword search (Persian or English, e.g. 'پوکو', 'galaxy', 'مودم')."),
    category_id: z.number().int().positive().optional().describe("Filter by category id (see list_categories)."),
    min_price: z.number().positive().optional().describe("Minimum price in Toman (IRT)."),
    max_price: z.number().positive().optional().describe("Maximum price in Toman (IRT)."),
    on_sale: z.boolean().optional().describe("Restrict to discounted products."),
    sort_by: z.enum(["default", "date", "price", "popularity", "rating", "title"]).optional().describe("Sort key."),
    order: z.enum(["asc", "desc"]).optional().describe("Sort direction."),
    page: z.number().int().positive().optional().describe("Page number (1-based)."),
    max_results: z.number().int().min(1).max(100).optional().describe("Results per page (default 20, max 100)."),
  },
  async ({ query, category_id, min_price, max_price, on_sale, sort_by, order, page, max_results }) => {
    try {
      const products = await client.searchProducts({
        query,
        categoryId: category_id,
        minPrice: min_price,
        maxPrice: max_price,
        onSale: on_sale,
        sortBy: sort_by || "date",
        order: order || "desc",
        page: page || 1,
        perPage: max_results || 20,
      });
      const items = products.map(summarizeProduct);
      return textResult({
        count: items.length,
        page: page || 1,
        note: "Prices are in Iranian Toman (IRT). Pass a product id to get_product_details for full info.",
        products: items,
      });
    } catch (error) {
      throw new Error(`search_products failed: ${error.message}`);
    }
  }
);

server.tool(
  "get_product_details",
  "Get full details for one product on digi333.ir by its numeric id (from search_products): description, attributes, gallery, stock, pricing.",
  {
    product_id: z.number().int().positive().describe("The numeric product id on digi333.ir."),
  },
  async ({ product_id }) => {
    try {
      const product = await client.getProduct(product_id);
      return textResult(expandProduct(product));
    } catch (error) {
      throw new Error(`get_product_details failed: ${error.message}`);
    }
  }
);

server.tool(
  "list_categories",
  "List product categories on digi333.ir. Omit parent_id for top-level categories; pass a category id to get its children.",
  {
    parent_id: z.number().int().positive().optional().describe("Parent category id to list children of."),
  },
  async ({ parent_id }) => {
    try {
      const categories = await client.listCategories({ parentId: parent_id });
      return textResult({
        count: categories.length,
        categories: categories.map((c) => ({
          id: c.id,
          name: c.name,
          slug: c.slug,
          count: c.count,
          parent: c.parent,
          link: c.permalink,
        })),
      });
    } catch (error) {
      throw new Error(`list_categories failed: ${error.message}`);
    }
  }
);

const transport = new StdioServerTransport();
await server.connect(transport);
